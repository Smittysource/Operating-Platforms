/*
 * GameAuthorizer.java
 * 
 * @author 			coce@snhu.edu
 * Modified by:		David Smith
 * Date:			March 27, 2021
 * Course:			CS-230
 * Course Title:	Operating Platforms
 * Submitted to:	Dr. Lyon
 * 
 * This class is an example authorization demonstration
 * for The Gaming Room's Draw It or Lose It game.
 * 
 * Modifications made are:
 * Coded the necessary return value evaluation to check if the user
 * has the passed in role.
 */
package com.gamingroom.gameauth.auth;

import io.dropwizard.auth.Authorizer;

public class GameAuthorizer implements Authorizer<GameUser> 
{
    @Override
    public boolean authorize(GameUser user, String role) {
    	
        /* If the user has at least one role and the roles include the passed
         * in role, return true. Otherwise, return false.
         * This code is based on the Dropwizard BasicAuth Security Example.
         */
    	return user.getRoles() != null && user.getRoles().contains(role);
    	
    }
}