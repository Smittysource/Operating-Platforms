/*
 * GameAuthenticator.java
 * 
 * @author 			coce@snhu.edu
 * Modified by:		David Smith
 * Date:			March 27, 2021
 * Course:			CS-230
 * Course Title:	Operating Platforms
 * Submitted to:	Dr. Lyon
 * 
 * This class is an example game authenticator
 * for The Gaming Room's Draw It or Lose It game.
 * 
 * Modifications made are:
 * Coded the necessary return value evaluation to check if the 
 * user credentials entered are valid.
 */
package com.gamingroom.gameauth.auth;


import io.dropwizard.auth.AuthenticationException;
import io.dropwizard.auth.Authenticator;
import io.dropwizard.auth.basic.BasicCredentials;
 
import java.util.Map;
import java.util.Optional;
import java.util.Set;
 
import com.google.common.collect.ImmutableMap;
import com.google.common.collect.ImmutableSet;
 
public class GameAuthenticator implements Authenticator<BasicCredentials, GameUser> 
{
		
	private static final Map<String, Set<String>> VALID_USERS = ImmutableMap.of(
        "guest", ImmutableSet.of(),
        "user", ImmutableSet.of("USER"),
        "admin", ImmutableSet.of("ADMIN", "USER"),
        "player", ImmutableSet.of("PLAYER")
    );
 
    @Override
    public Optional<GameUser> authenticate(BasicCredentials credentials) throws AuthenticationException 
    {
        if (VALID_USERS.containsKey(credentials.getUsername()) && "password".equals(credentials.getPassword())) 
        {
            /* Returns whether or not the user entered credentials entered are valid.
             * This code is based on the Dropwizard BasicAuth Security Example.
             */
        	return Optional.of(new GameUser(credentials.getUsername(), VALID_USERS.get(credentials.getUsername())));
        }
        return Optional.empty();
    }
}
